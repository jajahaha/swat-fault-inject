class _JRuntime:
    pass
